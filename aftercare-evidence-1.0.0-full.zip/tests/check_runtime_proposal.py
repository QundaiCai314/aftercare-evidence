import copy,json
from pathlib import Path
from jsonschema import Draft202012Validator,FormatChecker,ValidationError
R=Path(__file__).resolve().parents[1]
s=json.loads((R/'candidate/runtime-records.schema.json').read_text(encoding='utf-8'))
v=Draft202012Validator(s,format_checker=FormatChecker())
grant={'grant_id':'grant-local','task_id':'task-synthetic','file_refs':['file-good'],'operations':['local_read'],'recipient':None,'purpose':'inspect','expires_at':'2026-09-28T00:00:00Z','user_event_ref':'event-grant'}
v.validate(grant)
remote=copy.deepcopy(grant);remote.update(grant_id='grant-remote',operations=['remote_analysis'],recipient='model-a',purpose='visual-analysis');v.validate(remote)
bad=copy.deepcopy(remote);bad['recipient']=None
try:v.validate(bad)
except ValidationError:pass
else:raise AssertionError('remote recipient missing accepted')
binding={'binding_id':'binding-1','task_id':'task-synthetic','target_item_ref':'item-cup','plan_ref':{'ref':'plan','revision':1},'requirements_ref':{'ref':'requirements','revision':1},'bundle_core_ref':{'ref':'bundle-core','revision':1},'bundle_digest':'a'*64,'user_decision_ref':{'ref':'decision','revision':1},'presentation_ref':'presentation','user_event_ref':'event-review','recorded_at':'2026-09-27T10:00:00Z'}
v.validate(binding)
for name,data in [('grant-local',grant),('grant-remote',remote),('review-binding',binding)]:
    (R/'candidate'/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(R/'tests/candidate-runtime-results.json').write_text(json.dumps({'structural_checks':4,'passed':4,'status':'proposal only; does not grant real capabilities or register events'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('4 runtime proposal structure checks passed')
