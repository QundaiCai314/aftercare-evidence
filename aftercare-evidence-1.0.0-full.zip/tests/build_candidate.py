"""Build a review-only strict schema; not a central protocol migration."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def obj(props,required=None):return {'type':'object','properties':props,'required':list(props) if required is None else required,'additionalProperties':False}
def arr(item):return {'type':'array','items':item}
def enum(*v):return {'enum':list(v)}
S={'type':'string','minLength':1}; N={'type':'null'}
REF={'type':'string','pattern':'^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$'}
HASH={'type':'string','pattern':'^[a-f0-9]{64}$'}
def nullable(s):return {'anyOf':[s,N]}
V=obj({'ref':REF,'revision':{'type':'integer','minimum':0}})
transform={'oneOf':[obj({'operation':{'const':'rotate'},'parameters':obj({'clockwise':enum(90,180,270),'metadata_removed':{'type':'boolean'}})}),obj({'operation':{'const':'compress'},'parameters':obj({'quality':{'type':'integer','minimum':1,'maximum':100},'max_bytes':{'type':'integer','minimum':1},'metadata_removed':{'type':'boolean'}})})]}
file=obj({'file_ref':REF,'version':{'type':'integer','minimum':0},'sha256':nullable(HASH),'label':S,'role':enum('inspected','selected','excluded'),'inspection_state':enum('not_inspected','readable','unreadable','unsupported','failed'),'processing_state':enum('not_needed','not_requested','derived','failed'),'purpose':enum('evidence','inference_only'),'reason_codes':arr(enum('suitable','unreadable','unsupported_format','decode_failure','not_authorized','unrelated','uncertain_match','pending_visual_review','transformation_failed','not_needed')),'source_refs':arr(REF),'transforms':arr(transform)})
requirement=obj({'requirement_id':REF,'level':enum('required','conditional','suggested','unknown'),'condition_ref':nullable(REF),'condition_state':enum('met','not_met','unknown','not_applicable'),'evidence_refs':arr(REF)})
requirement['allOf']=[{'if':{'properties':{'level':{'const':'conditional'}}},'then':{'properties':{'condition_ref':REF,'condition_state':enum('met','not_met','unknown')}}}]
check=obj({'requirement_id':REF,'state':enum('met','missing','uncertain'),'reason_codes':arr(enum('visible_content','file_absent','size_unknown','size_exceeded','unclear','unrelated','context_loss','condition_unknown','user_conflict','not_required')),'evidence_refs':arr(REF)})
statement=obj({'statement_id':REF,'text':S,'basis':enum('user_reported','observed','uncertain'),'evidence_refs':arr(REF),'confirmation':enum('pending','confirmed','corrected')})
schema=obj({'profile':{'const':'evidence-assessment-candidate-1'},'task_id':REF,'target_item_ref':REF,'bundle_ref':V,'plan_ref':V,'requirements_ref':V,'files':arr(file),'selected_file_refs':{'type':'array','items':REF,'uniqueItems':True},'requirements':arr(requirement),'checks':arr(check),'statements':arr(statement),'review_binding_ref':nullable(REF),'upload_authorized':{'const':False}})
schema['$schema']='https://json-schema.org/draft/2020-12/schema'
(ROOT/'candidate').mkdir(exist_ok=True)
(ROOT/'candidate/evidence-assessment.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
grant=obj({'grant_id':REF,'task_id':REF,'file_refs':arr(REF),'operations':arr(enum('local_read','local_transform','remote_analysis','upload')),'recipient':nullable(REF),'purpose':S,'expires_at':{'type':'string','format':'date-time'},'user_event_ref':REF})
grant['allOf']=[{'if':{'properties':{'operations':{'contains':enum('remote_analysis','upload')}}},'then':{'properties':{'recipient':REF}}}]
binding=obj({'binding_id':REF,'task_id':REF,'target_item_ref':REF,'plan_ref':V,'requirements_ref':V,'bundle_core_ref':V,'bundle_digest':HASH,'user_decision_ref':V,'presentation_ref':REF,'user_event_ref':REF,'recorded_at':{'type':'string','format':'date-time'}})
runtime={'$schema':schema['$schema'],'$defs':{'FileGrant':grant,'ReviewBinding':binding},'oneOf':[{'$ref':'#/$defs/FileGrant'},{'$ref':'#/$defs/ReviewBinding'}]}
(ROOT/'candidate/runtime-records.schema.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
