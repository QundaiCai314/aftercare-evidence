"""Offline candidate invariants; trusted fixture records are NOT authentication."""
import hashlib,json
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def review_core(a):
    files={f['file_ref']:f for f in a['files']}
    selected=set(a['selected_file_refs']); pending=list(selected)
    while pending:
        f=files[pending.pop()]
        for r in f['source_refs']:
            if r not in selected:selected.add(r);pending.append(r)
    return {'task_id':a['task_id'],'target_item_ref':a['target_item_ref'],'plan_ref':a['plan_ref'],'requirements_ref':a['requirements_ref'],'selected_file_refs':sorted(a['selected_file_refs']),'files':[{k:f[k] for k in ('file_ref','version','sha256','source_refs','transforms','purpose')} for f in sorted((files[r] for r in selected),key=lambda f:f['file_ref'])],'statements':[{k:s[k] for k in ('statement_id','text','basis','evidence_refs')} for s in a['statements']]}
def check(a,host):
    def need(ok,why):
        if not ok:raise ValueError(why)
    need(a['task_id']==host['task_id'] and a['target_item_ref']==host['target_item_ref'],'target')
    need(a['plan_ref']==host['plan_ref'] and a['requirements_ref']==host['requirements_ref'],'context_revision')
    need(host['target_valid'] and host['choice_valid'] and host['requirements_current'],'upstream_validity')
    files={f['file_ref']:f for f in a['files']}
    need(len(files)==len(a['files']),'duplicate_file')
    for f in a['files']:
        row=host['files'].get(f['file_ref'])
        need(row is not None,'missing_file')
        need(row['task_id']==a['task_id'] and row['authorized'] and row['active'],'file_scope')
        if f['sha256'] is not None:need(f['sha256']==row['sha256'] and f['version']==row['version'],'content_changed')
        for source in f['source_refs']:need(source in files,'source_missing')
        need(f['source_refs']==row['source_refs'] and f['transforms']==row['transforms'],'provenance')
        if f['processing_state']=='derived':need(row['exists'] and bool(f['source_refs']) and bool(f['transforms']),'unreal_derived')
    def visit(r,path):
        need(r not in path,'source_cycle')
        for s in files[r]['source_refs']:visit(s,path|{r})
    for r in files:visit(r,set())
    selected=a['selected_file_refs'];need(len(set(selected))==len(selected),'duplicate_selected')
    need(set(selected)=={f['file_ref'] for f in a['files'] if f['role']=='selected'},'selected_roles')
    for r in selected:
        f=files[r];row=host['files'][r]
        need(f['inspection_state']=='readable' and f['processing_state'] not in ('failed','not_requested') and f['sha256'] is not None and f['purpose']=='evidence','selected_unusable')
        need(row['exists'] and row['readable'] and row['visual_verified'],'selected_unverified')
    requirements={r['requirement_id']:r for r in a['requirements']};checks={c['requirement_id']:c for c in a['checks']}
    need(len(requirements)==len(a['requirements']) and len(checks)==len(a['checks']),'duplicate_requirement')
    need(requirements==host['requirements'] and set(checks)==set(requirements),'requirement_mapping')
    for c in a['checks']:
        r=requirements[c['requirement_id']]
        need(bool(c['reason_codes']),'missing_reason')
        if c['state']=='met':
            need(bool(c['evidence_refs']),'missing_evidence')
            need(host['verified_checks'].get(c['requirement_id'])==c,'unchecked_claim')
        for e in c['evidence_refs']+r['evidence_refs']:
            need(e in host['evidence'] and host['evidence'][e]['task_id']==a['task_id'],'evidence_scope')
        need(r['level']!='unknown' and not (r['level']=='conditional' and r['condition_state']=='unknown'),'requirement_unknown')
        if r['level']=='required' or (r['level']=='conditional' and r['condition_state']=='met'):
            need(c['state']=='met','required_missing')
    for s in a['statements']:
        need(bool(s['evidence_refs']) and all(e in host['evidence'] and host['evidence'][e]['task_id']==a['task_id'] for e in s['evidence_refs']),'statement_sources')
        need(host['verified_statements'].get(s['statement_id'])=={k:s[k] for k in ('text','basis','evidence_refs')},'statement_unverified')
    b=host['reviews'].get(a['review_binding_ref']);need(b is not None,'review_missing')
    need(b['task_id']==a['task_id'] and b['digest']==digest(review_core(a)) and b['active'],'review_binding')
    event=host['events'].get(b['event_ref'])
    need(event is not None and event['source']=='user' and event['explicit'] and event['kind']=='review_material' and event['presentation_ref']==b['presentation_ref'],'review_event')
    return {'content_review_valid':True,'candidate_preparation_check':True,'central_v1_handoff_allowed':False,'upload_authorized':False}

def resolve_local(ref, approved, task, registry):
    if ref not in approved:raise ValueError('not_approved')
    row=registry.get(ref)
    if not row or row['task_id']!=task or not row['authorized'] or not row['active']:raise ValueError('invalid_scope')
    return row

def remote_allowed(row,recipient,purpose,now):
    return any(g['recipient']==recipient and g['purpose']==purpose and g['expires_at']>now for g in row.get('remote_grants',[]))
