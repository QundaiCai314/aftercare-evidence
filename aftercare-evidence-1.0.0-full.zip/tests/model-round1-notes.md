# 独立前向执行记录

只读取 aftercare-evidence/SKILL.md、contract/assessment/files/review.md、正式 evidence.schema.json 与 forward-inputs.json。未读取 cases.json、作者答案或候选协议。逐例按提供的合成观察生成完整结果 body，未实际读图、检查凭证字节、处理媒体、访问网络、浏览器、Spark 或安装组件。

共生成22个结果；身份与修订对应请求。无派生文件、无核对凭证引用、无上传准备放行。只有02提供文件可读、格式、大小和内容均合适的宿主观察，因此将其原件引用保留。其余病例不把批准列表本身当作已完成来源/格式/内容检查的证据。用户陈述与观察分开写入说明，缺来源引用不自造ID。

接口与输入限制：
- contract.md 要求宿主已验证同一不可变 plan revision 内 key 唯一且与当前页面一致才能生成 requirement_key。共享上下文虽然列出同名同文事实，但没有给出宿主核验状态；因此所有 requirement_checks 留空，并记录 missing_input。已知照片要求仍用自然语言指导。若 intended test 希望有结构化 met/missing/uncertain，须明确提供这一宿主观察，而不能让我自行把文字一致当成验证。
- 04的 file-large、05的 file-blur 不在批准列表中；15的多个检测状态未绑定具体引用。已保留这些差异，未将状态转移到 file-good。
- v1 无字段结构化记录拟用集合、逐项技术检查、材料类型、说明逐句来源、已不能补拍及失效绑定。只在允许的说明、问题、issues、user_message 中表达，不将文本当放行门禁。
- 18已有用户认可但没有正式绑定机制，返回 blocked/contract_error，未再索取相同认可。
- 21授权旋转不等于给出旋转角度、EXIF方向、支持格式或实际输出登记。本轮禁止执行处理，未声称生成副本。
- 22更正事实后更新说明，不沿用旧描述或杜撰时间/责任。
- 生成的 result 为 aftercare-evidenceResult body；没有额外 transport envelope，以匹配要求的 {id,result} 数组。

