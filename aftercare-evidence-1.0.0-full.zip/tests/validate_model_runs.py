"""Validate recorded real model responses, not generate or score language."""
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
s=read(ROOT/'aftercare-evidence/references/evidence.schema.json')
v=Draft202012Validator({'$defs':s['$defs'],'$ref':'#/$defs/aftercare-evidenceResult'},format_checker=FormatChecker())
report=[]
for run,inputs in [('model-round1.json','forward-inputs.json'),('model-round2.json','forward-inputs-round2.json'),('model-regression.json','forward-inputs-round2.json')]:
    path=ROOT/'tests'/run
    if not path.exists():continue
    cases={c['id']:c for c in read(ROOT/'tests'/inputs)['cases']}
    rows=read(path)
    for row in rows:
        r=row['result'];q=cases[row['id']]['request'];v.validate(r)
        assert all(r[k]==q[k] for k in ('contract_version','skill_id','call_id','task_id'))
        assert r['based_on_task_revision']==q['expected_task_revision'] and r['data'] is not None
        assert not r['data']['derived_files'] and r['data']['review_receipt_ref'] is None
        assert set(r['data']['original_file_refs'])<=set(q['inputs']['approved_file_refs'])
    report.append({'file':run,'results':len(rows),'schema_identity_and_no_forged_output':'pass','semantic_scoring':'separate author review; no automatic behavior pass rate'})
(ROOT/'tests/model-structure-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(report)
