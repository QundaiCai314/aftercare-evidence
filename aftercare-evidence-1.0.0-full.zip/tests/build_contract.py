"""Rebuild the derived definitions from the recorded central authority only."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'aftercare-evidence/references/provenance.json'
record=json.loads(p.read_text(encoding='utf-8'));source=record['sources'][0]
raw=Path(source['path']).read_bytes()
if hashlib.sha256(raw).hexdigest()!=source['sha256']:raise SystemExit('Central contract changed: review version before rebuilding')
central=json.loads(raw.decode('utf-8-sig'));names=set()
def collect(value):
    if isinstance(value,dict):
        if '$ref' in value:
            name=value['$ref'].split('/')[-1]
            if name not in names:names.add(name);collect(central['$defs'][name])
        for v in value.values():collect(v)
    elif isinstance(value,list):
        for v in value:collect(v)
for n in record['definitions']:collect({'$ref':'#/$defs/'+n})
schema={'$schema':central['$schema'],'$defs':{n:central['$defs'][n] for n in sorted(names)},'oneOf':[{'$ref':'#/$defs/aftercare-evidenceRequest'},{'$ref':'#/$defs/aftercare-evidenceResult'}]}
(ROOT/'aftercare-evidence/references/evidence.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Rebuilt',len(names),'unchanged central definitions')
